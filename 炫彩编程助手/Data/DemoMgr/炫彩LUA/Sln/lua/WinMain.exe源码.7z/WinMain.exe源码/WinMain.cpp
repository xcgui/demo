// WinMain.cpp : Defines the entry point for the console application.
//

#include "Common.h"


int APIENTRY _tWinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPTSTR lpCmdLine, int nCmdShow)
{

	CCmdLine cmd;
	if (cmd.GetArgCount() != 2)
	{
		MessageBoxW(NULL,L"�����в���С��2",L"����",MB_OK);
		return 0;
	}
	
	int nLen = XC_UnicodeToAnsi(cmd[1],-1,NULL,NULL)+1;
	char* pBufferA = new char[nLen];
	ZeroMemory(pBufferA,nLen);
	XC_UnicodeToAnsi(cmd[1],-1,pBufferA,nLen);

	XInitXCGUI();
	XC_InitLua();
	XC_RunLua(pBufferA);

	XRunXCGUI();
	XC_ExitLua();
	XExitXCGUI();

	delete [] pBufferA;
	return 0;
}
